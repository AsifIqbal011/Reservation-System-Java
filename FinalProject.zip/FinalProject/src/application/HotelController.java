package application;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import uap.HotelRoom;
import uap.NotAvailableException;
import uap.Vehicle;


public class HotelController implements Initializable {
    ObservableList<HotelRoom> hotelList = FXCollections.observableArrayList();

	    @FXML
	    private TextField honame,noGuest,hMaxPrice,hMinPrice;
	    @FXML
	    private DatePicker startDate,endDate;
	    @FXML
	    private CheckBox AcBox;
	    @FXML
	    private Label payLable;

	    @FXML
	    private TableColumn<HotelRoom, String> hotelName;

	    @FXML
	    private TableColumn<HotelRoom, Integer> hotelPrice;

	    @FXML
	    private TableColumn<HotelRoom, Integer> hotelRank;

	    @FXML
	    private TableView<HotelRoom> hotelTable;
	    @FXML
	    private TableColumn<HotelRoom, Boolean> hotelAc;;
	    @FXML
	    private TableColumn<HotelRoom, Boolean> hAvailable;
	    
	    @FXML
	    private Button money,pay,backButton;

	    
	    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		hotelName.setCellValueFactory(new PropertyValueFactory<>("hotelName"));  
		 hotelRank.setCellValueFactory(new PropertyValueFactory<>("rankOfHotel"));
    	hotelPrice.setCellValueFactory(new PropertyValueFactory<>("rate"));
    	hAvailable.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAvailable()));
    	hotelAc.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().hasAC()));
    	hotelTable.setItems(hotelList);
    	 payLable.setVisible(false);
    	 if(!Main.currentUser.isAdmin()) {backButton.setVisible(false);}
		try {
			hotelList.setAll(Main.reservationSystem.getRooms());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
		
	}
	
	public void findHotel(ActionEvent event) throws IOException {
		String hoName = honame.getText();
		int hcapacity = Integer.parseInt( noGuest.getText());
		int HMaxRate = Integer.parseInt(hMaxPrice.getText());
		int HMinRate = Integer.parseInt( hMinPrice.getText());
		boolean hasAc = AcBox.isSelected();
		try {
			hotelList.clear();
			if(hMaxPrice.getText().isBlank()||hMinPrice.getText().isBlank()) {
				hotelList.setAll(Main.reservationSystem.findRooms(hoName, hcapacity, hasAc));
			}else {
				hotelList.setAll(Main.reservationSystem.findRooms(hoName, hcapacity, hasAc, HMinRate, HMaxRate));
			}
			
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}	
	}
	
	
	public void reserveHotel(ActionEvent event) {
		HotelRoom hotel=hotelTable.getSelectionModel().getSelectedItem();
		  String StartDate =  startDate.getValue().toString();
		  String EndDate =  endDate.getValue().toString();
		try {
			Main.reservationSystem.reserve(hotel, Main.currentUser.getId(), StartDate, EndDate);
			hotelList.setAll(Main.reservationSystem.getRooms());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	
	}
	
	public void payHotel(ActionEvent event) {
		HotelRoom hotel=hotelTable.getSelectionModel().getSelectedItem();
		try {
			double price=Main.reservationSystem.makePayment(hotel.getId());
			payLable.setText(""+price+" tk");
			 payLable.setVisible(true);
			 money.setVisible(true);
			 hotelList.setAll(Main.reservationSystem.getRooms());

		} catch (NotAvailableException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void sendMoney(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "Payment Complete");
		payLable.setVisible(false);
		money.setVisible(false);
	}
	public void cancleHotel(ActionEvent event) {
		HotelRoom hotel=hotelTable.getSelectionModel().getSelectedItem();
		try {
			Main.reservationSystem.cancelReservation(hotel);
			hotelList.setAll(Main.reservationSystem.getRooms());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	public void backBtn(ActionEvent event) throws IOException {
		if(Main.currentUser.isAdmin()) {
			goToPage("Add.fxml");
		}else {
			goToPage("SignUp.fxml");
		}
	}
	public void goToVehicle(ActionEvent event) throws IOException {
		goToPage("Vehicle.fxml");
	}
	public void goToRestaurant(ActionEvent event) throws IOException {
		goToPage("Restaurant.fxml");
	}
	public void logOut(ActionEvent event) throws IOException {
		goToPage("SignUp.fxml");
	}
	public void goToPage(String page) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource(page));
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}
}
