package application;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import uap.DataHandler;
import uap.ReservationSystem;
import uap.User;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;



public class Main extends Application {
	
	public static ReservationSystem reservationSystem = null;
	public static User currentUser= null;
	public static boolean isAdmin = false;

	public static Stage stage;
	@Override
	public void start(Stage primaryStage){
		loadSystem();
		try {	
			stage = primaryStage;
			AnchorPane root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
			Scene scene = new Scene(root);
			Image icon=new Image("reserve.png");
			primaryStage.getIcons().add(icon);
			primaryStage.setTitle("Reservation System");
			primaryStage.setScene(scene);
			primaryStage.show();
			
			primaryStage.setOnCloseRequest(e -> {
                saveSystem();
                System.exit(0);
            });
			}
			 catch (IOException e) {
					e.printStackTrace();
				}
	}
	
	 public static void loadSystem() {
	        try {
	        	reservationSystem = DataHandler.loadData();
	            System.out.println("Data loaded successfully");
	        } catch (Exception e) {
	        	reservationSystem = new ReservationSystem("My Project");
	            System.out.println("Failed to load data. Created new property");
	        }
	    }

	    public static void saveSystem() {
	        try {
	            DataHandler.saveData(reservationSystem);
	            System.out.println("Data saved successfully");
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	    
	public static void main(String[] args) {
		launch(args);
	}
}
