package application;

import java.io.IOException;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.scene.Scene;
import javafx.scene.control.Button;


	public class AdminControle {
		@FXML
		TextField modelTf,capacityTf,egPowerTf,rateTf, rsNameTf, rsCapacityTf, rsRateTf,htNameTf, htOccupancyTf,htRankTf,htRateTf;
		@FXML
		CheckBox yesBox;
		
		@FXML
	    private Button hotelBtn,restBtn,vehicleBtn;

	    @FXML
	    private AnchorPane hotelForm, restFrom,vehicleForm;
	    @FXML
	    private Text title;
	 
	    
	    public void switchForm(ActionEvent event) throws Exception {
	    	if(event.getSource()==vehicleBtn) {
	    		hotelForm.setVisible(false);
	    		restFrom.setVisible(false);
	    		vehicleForm.setVisible(true);
	    	}else if(event.getSource()==restBtn) {
	    		hotelForm.setVisible(false);
	    		restFrom.setVisible(true);
	    		vehicleForm.setVisible(false);
	    	}else if(event.getSource()==hotelBtn) {
	    		hotelForm.setVisible(true);
	    		restFrom.setVisible(false);
	    		vehicleForm.setVisible(false);
	    	}
	    }
	   
	    void resetVehicleForm() {
	    	modelTf.clear();
	    	capacityTf.clear();
	    	egPowerTf.clear();
	    	rateTf.clear();
	    }
	    void resetHotelForm() {
	    	htNameTf.clear();
	    	htOccupancyTf.clear();
	    	htRankTf.clear();
	    	htRateTf.clear();
	    	yesBox.setSelected(false);
	    }
	    void resetRestForm() {
	    	rsNameTf.clear();
	    	rsCapacityTf.clear();
	    	rsRateTf.clear();
	    }
	    public void addVehicle(ActionEvent event) throws IOException {
			String model = modelTf.getText();
			int capacity = Integer.parseInt( capacityTf.getText());
			float egPower =Float.parseFloat(egPowerTf.getText());
			Double rate = Double.parseDouble( rateTf.getText());
		String id=	Main.reservationSystem.addItem(model, capacity, egPower, rate);
			JOptionPane.showMessageDialog(null, "Vehicle Added ID:"+id);
			resetVehicleForm();
	    }
	    public void addHotel(ActionEvent event) throws IOException {
			String htName = htNameTf.getText();
			int htOccupancy = Integer.parseInt( htOccupancyTf.getText());
			int htRank = Integer.parseInt( htRankTf.getText());
			Double htRate = Double.parseDouble( htRateTf.getText());
			boolean htHasAc = yesBox.isSelected();
		String	id= Main.reservationSystem.addItem(htName, htRank, htOccupancy, htHasAc, htRate);
			JOptionPane.showMessageDialog(null, "Hotel Added ID:"+id);	
			resetHotelForm();
	    }
	    public void addRestaurant(ActionEvent event) throws IOException {
			String rsName = rsNameTf.getText();
			int rscapacity = Integer.parseInt( rsCapacityTf.getText());
			Double rsRate = Double.parseDouble( rsRateTf.getText());
			String id= Main.reservationSystem.addItem(rsName, rscapacity, rsRate);
			JOptionPane.showMessageDialog(null, "Restaurant Added ID:"+id);
			resetRestForm();
	    }
	    public void goToVehicle(ActionEvent event) throws IOException {
	 			AnchorPane root = FXMLLoader.load(getClass().getResource("Vehicle.fxml"));
	 			Scene scene = new Scene(root);			
	 			Main.stage.setScene(scene);
	 			Main.stage.show();
	 		}
	    public void goToPanel(ActionEvent event) throws IOException {
 			AnchorPane root = FXMLLoader.load(getClass().getResource("viewMore.fxml"));
 			Scene scene = new Scene(root);			
 			Main.stage.setScene(scene);
 			Main.stage.show();
 		}
		public void logOut(ActionEvent event) throws IOException {
			AnchorPane root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}
		public void viewAll(ActionEvent event) throws IOException {
			AnchorPane root = FXMLLoader.load(getClass().getResource("viewMore.fxml"));
			Scene scene = new Scene(root);			
			Main.stage.setScene(scene);
			Main.stage.show();
		}
}
