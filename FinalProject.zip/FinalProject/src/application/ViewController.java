package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import uap.Item;
import uap.ReservationRecord;
import uap.User;
import uap.Vehicle;

public class ViewController implements Initializable {
	 ObservableList<ReservationRecord> RecordList = FXCollections.observableArrayList();
	 ObservableList<User> UserList = FXCollections.observableArrayList();
	 ObservableList<Item> ItemList = FXCollections.observableArrayList();
	    @FXML
	    private Button userBtn,recordBtn, ItemBtn;
	    @FXML
	    private AnchorPane itemForm,recordFrom,userForm;
	    @FXML
	    private TableView<User> utable;
	    
	    @FXML
	    private TableColumn<User,String> uname;
	    
	    @FXML
	    private TableColumn<User,Integer > uage;
 
	    @FXML
	    private TableColumn<User, String> uId;

	    @FXML
	    private TableColumn<User, Boolean> uIsAdmin;
	    @FXML
	    private TableView<ReservationRecord> rTable;
	    
	    @FXML
	    private TableColumn<ReservationRecord, String> rId;
	    
	    @FXML
	    private TableColumn<ReservationRecord, String> rItemid;

	    @FXML
	    private TableColumn<ReservationRecord, String> rUserid;
	    
	    @FXML
	    private TableColumn<ReservationRecord, String> rNote;
	    
	    @FXML
	    private TableColumn<ReservationRecord, LocalDate> rStartdate;
	
	    @FXML
	    private TableColumn<ReservationRecord, LocalDate> rEnddate;

	    @FXML
	    private TableColumn<ReservationRecord, Integer> rQuantity;

	    @FXML
	    private TableColumn<Item, Double> IRate;

	    @FXML
	    private TableColumn<Item, Boolean> iAvailable;

	    @FXML
	    private TableColumn<Item, String> iID;

	    @FXML
	    private TableColumn<Item, String> iName;

	    @FXML
	    private TableColumn<Item, String> iRecID;

	    @FXML
	    private TableView<Item> iTable;
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) 
		{
			//iName.setCellValueFactory(new PropertyValueFactory<>("name"));  
			IRate.setCellValueFactory(new PropertyValueFactory<>("rate"));
	    	iID.setCellValueFactory(new PropertyValueFactory<>("id"));
	    	//iRecID.setCellValueFactory(new PropertyValueFactory<>("lRecordId"));
	    	iAvailable.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAvailable()));
		    iTable.setItems(ItemList);
		    ItemList.setAll(Main.reservationSystem.getItems());
			
			
			uname.setCellValueFactory(new PropertyValueFactory<>("name"));  
	    	uage.setCellValueFactory(new PropertyValueFactory<>("age"));
	    	uId.setCellValueFactory(new PropertyValueFactory<>("id"));
	    	uIsAdmin.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAdmin()));
		    utable.setItems(UserList);
		    UserList.setAll(Main.reservationSystem.getUsers());
		
		    rId.setCellValueFactory(new PropertyValueFactory<>("id"));  
			rItemid.setCellValueFactory(new PropertyValueFactory<>("itemId"));
			rUserid.setCellValueFactory(new PropertyValueFactory<>("userId"));
			rNote.setCellValueFactory(new PropertyValueFactory<>("note")); 
			rStartdate.setCellValueFactory(new PropertyValueFactory<>("reservation_start_date")); 
			rEnddate.setCellValueFactory(new PropertyValueFactory<>("reservation_start_date")); 
			rQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity")); 
	    	uIsAdmin.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAdmin()));
			rTable.setItems(RecordList);
			RecordList.setAll(Main.reservationSystem.getRecord());
		
		}
		
		public void switchForm(ActionEvent event) throws Exception {
	    	if(event.getSource()==recordBtn) {
	    		 itemForm.setVisible(false);
	    		 userForm.setVisible(false);
	    		 recordFrom.setVisible(true);
	    	}else if(event.getSource()== userBtn) {
	    		 itemForm.setVisible(false);
	    		 userForm.setVisible(true);
	    		 recordFrom.setVisible(false);
	    	}else if(event.getSource()== ItemBtn) {
	    		 itemForm.setVisible(true);
	    		 userForm.setVisible(false);
	    		 recordFrom.setVisible(false);
	    	}
	    }
	
		public void removeItem(ActionEvent event) {
			Item item= iTable.getSelectionModel().getSelectedItem();
			Main.reservationSystem.removeItem(item);
			ItemList.setAll(Main.reservationSystem.getItems());
		}

    public void logOut(ActionEvent event) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}
    public void backBtn(ActionEvent event) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("Add.fxml"));
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}

}
