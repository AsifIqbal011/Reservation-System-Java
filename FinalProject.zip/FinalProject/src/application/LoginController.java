package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import uap.InvalidUserException;
import uap.ReservationSystem;
import uap.User;

public class LoginController implements Initializable  {
	@FXML TextField idTf,nameTf,ageTf;
	@FXML CheckBox yesBox;
	 
	public void logIn(ActionEvent event) {
		String userID = idTf.getText();
		if(userID==null||userID.isBlank()) {
			return;
		}
			try {
				User user = Main.reservationSystem.findUser(userID);
				Main.currentUser=user;
				if(user.isAdmin()) {
					showAdmin();
				}else {
				showCustomer();}
			}
			 catch (InvalidUserException e) {
					JOptionPane.showMessageDialog(null, "Login Failed");
					e.printStackTrace();
				}
	}
	

	
	public void signUp(ActionEvent event) {
		
		String userName= nameTf.getText();
		int userAge =Integer.parseInt( ageTf.getText());
		boolean userIsAdmin = yesBox.isSelected();
		if(userName==null||userName.isBlank()) {
			return;
		}
		String id= Main.reservationSystem.addUser(userName, userAge, userIsAdmin);
		JOptionPane.showMessageDialog(null, "ID:"+id);
	}
	
	public void showAdmin(){
		AnchorPane root=null;
		try {
			root = FXMLLoader.load(getClass().getResource("Add.fxml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}
	public void showCustomer() {
		AnchorPane root=null;
		try {
			root = FXMLLoader.load(getClass().getResource("Vehicle.fxml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}

}
 