package application;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import uap.NotAvailableException;
import uap.Restaurant;

public class RestaurantController implements Initializable  {
    ObservableList<Restaurant> restaurantList = FXCollections.observableArrayList();

	@FXML TextField rsNameTf,rsCapacityTf,rsMaxPrice,rsMinPrice,rsNoOfGuest;

    @FXML
    private TableView<Restaurant> rsTable;
    @FXML
    private TableColumn<Restaurant, Integer> rsCapacity;
    @FXML
    private TableColumn<Restaurant, String> rsName;
    @FXML
    private TableColumn<Restaurant, Integer> rsPrice;
    @FXML
    private DatePicker startDate,endDate;
    @FXML
    private Label payLable;

    @FXML
    private Button money,pay,backButton;
    @FXML
    private TableColumn<Restaurant, Boolean> rsAvailable;
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	rsName.setCellValueFactory(new PropertyValueFactory<>("restaurantName"));  
    	rsCapacity.setCellValueFactory(new PropertyValueFactory<>("capacity"));
    	rsPrice.setCellValueFactory(new PropertyValueFactory<>("rate"));
    	rsAvailable.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAvailable()));
    	rsTable.setItems(restaurantList);
    	 payLable.setVisible(false);
    	 if(!Main.currentUser.isAdmin()) {backButton.setVisible(false);}
		try {
			restaurantList.setAll(Main.reservationSystem.getRestaurants());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
	}
	
	public void findRestaurant(ActionEvent event) throws IOException {
		String rsName = rsNameTf.getText();
		int rscapacity = Integer.parseInt( rsCapacityTf.getText());
		int rsMaxRate = Integer.parseInt( rsMaxPrice.getText());
		int rsMinRate = Integer.parseInt( rsMinPrice.getText());
		
		try {
			restaurantList.clear();
			if(rsName==null||rsName.isBlank()) {
				restaurantList.setAll(Main.reservationSystem.findRestaurants(rscapacity, rsMinRate, rsMaxRate));
			}else {
				restaurantList.setAll(Main.reservationSystem.findRestaurants(rsName, rscapacity, rsMinRate, rsMaxRate));
			}
			
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public void reserveRestaurant(ActionEvent event) 
	{
		Restaurant restaurant=rsTable.getSelectionModel().getSelectedItem();
		  String StartDate =  startDate.getValue().toString();
		  String EndDate =  endDate.getValue().toString();
		  int noOfGuest= Integer.parseInt( rsNoOfGuest.getText());
		try 
		{
			Main.reservationSystem.reserve(restaurant, Main.currentUser, noOfGuest, StartDate, EndDate);
			restaurantList.setAll(Main.reservationSystem.getRestaurants());
		} 
		catch (NotAvailableException e) 
		{
			e.printStackTrace();
		} 
		catch (ParseException e)
		{
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	public void cancleRestaurant(ActionEvent event) 
	{
		Restaurant restaurant=rsTable.getSelectionModel().getSelectedItem();
		try 
		{
			Main.reservationSystem.cancelReservation(restaurant);
			restaurantList.setAll(Main.reservationSystem.getRestaurants());
		} 
		catch (NotAvailableException e) 
		{
			e.printStackTrace();
		}
	}
	
	

public void payRestaurant(ActionEvent event)
{
	Restaurant restaurant=rsTable.getSelectionModel().getSelectedItem();
	try 
	{
		double price=Main.reservationSystem.makePayment(restaurant.getId());
		payLable.setText(""+price+" tk");
		 payLable.setVisible(true);
		 money.setVisible(true);
		 restaurantList.setAll(Main.reservationSystem.getRestaurants());

	}
	catch (NotAvailableException e) 
	{
		e.printStackTrace();
	}
	catch (Exception e) 
	{
		e.printStackTrace();
	}
}
public void sendMoney(ActionEvent event) {
	JOptionPane.showMessageDialog(null, "Payment Complete");
	payLable.setVisible(false);
	money.setVisible(false);
}
	
	public void backBtn(ActionEvent event) throws IOException {
		if(Main.currentUser.isAdmin()) {
			goToPage("Add.fxml");
		}else {
			goToPage("SignUp.fxml");
		}
	}
	
	public void goToVehicle(ActionEvent event) throws IOException {
		goToPage("Vehicle.fxml");
	}
	public void goToHotel(ActionEvent event) throws IOException {
		goToPage("HotelRoom.fxml");
	}
	public void logOut(ActionEvent event) throws IOException {
		goToPage("SignUp.fxml");
	}
	public void goToPage(String page) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource(page));
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}

	
}
