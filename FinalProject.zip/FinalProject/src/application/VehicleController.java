package application;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import uap.InvalidUserException;
import uap.NotAvailableException;
import uap.User;
import uap.Vehicle;

public class VehicleController implements Initializable {
	 ObservableList<Vehicle> vehicleList = FXCollections.observableArrayList();
		@FXML
		private TextField vMinPrice,vCapacityTF, vMaxPrice;
		@FXML
		private DatePicker startDate, endDate;
		
		@FXML
	    private TableColumn<Vehicle, Float> EgPower;

	    @FXML
	    private TableColumn<Vehicle, Integer> vCapacity;

	    @FXML
	    private TableColumn<Vehicle, Boolean> vAvailable;

	    @FXML
	    private TableColumn<Vehicle, String> vModel;

	    @FXML
	    private TableColumn<Vehicle, Integer> vPrice;

	    @FXML
	    private TableView<Vehicle> vehicleTable;
	    @FXML
	    private Label payLable;
	    @FXML
	    private Button money,pay,backButton;
	  
	    
	public void backBtn(ActionEvent event) throws IOException {
		if(Main.currentUser.isAdmin()) {
			goToPage("Add.fxml");
		}else {
			goToPage("SignUp.fxml");
		}
	}
	public void goToRestaurant(ActionEvent event) throws IOException {
		goToPage("Restaurant.fxml");
	}
	public void goToHotel(ActionEvent event) throws IOException {
		goToPage("HotelRoom.fxml");
	}
	public void logOut(ActionEvent event) throws IOException {
		goToPage("SignUp.fxml");
	}
	public void goToPage(String page) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource(page));
		Scene scene = new Scene(root);			
		Main.stage.setScene(scene);
		Main.stage.show();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		 payLable.setVisible(false);

		vModel.setCellValueFactory(new PropertyValueFactory<>("model"));  
    	vCapacity.setCellValueFactory(new PropertyValueFactory<>("capacity"));
    	vPrice.setCellValueFactory(new PropertyValueFactory<>("rate"));
    	EgPower.setCellValueFactory(new PropertyValueFactory<>("enginePower"));
    	vAvailable.setCellValueFactory(cellData -> new SimpleBooleanProperty(cellData.getValue().isAvailable()));
    	vehicleTable.setItems(vehicleList);
    	 payLable.setVisible(false);
    	 if(!Main.currentUser.isAdmin()) {backButton.setVisible(false);}
		try {
			vehicleList.setAll(Main.reservationSystem.getVehicles());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
		
	}
	
	public void findVehicle(ActionEvent event) throws IOException {
	
		int vcapacity = Integer.parseInt( vCapacityTF.getText());
		int vMaxRate = Integer.parseInt( vMaxPrice.getText());
		int vMinRate = Integer.parseInt(vMinPrice.getText());
		
		try {
				vehicleList.clear();
				vehicleList.setAll(Main.reservationSystem.findVehicles(vcapacity, vMinRate,vMaxRate));
			
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
		
		
	}
	public void reserveVehicle(ActionEvent event) {
		Vehicle vehicle=vehicleTable.getSelectionModel().getSelectedItem();
		  String StartDate =  startDate.getValue().toString();
		  String EndDate =  endDate.getValue().toString();
		try {
			Main.reservationSystem.reserve(vehicle, Main.currentUser.getId(), StartDate, EndDate);
			vehicleList.setAll(Main.reservationSystem.getVehicles());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	
	}
	public void payVehicle(ActionEvent event) {
		Vehicle vehicle=vehicleTable.getSelectionModel().getSelectedItem();
		try {
			double price=Main.reservationSystem.makePayment(vehicle.getId());
			payLable.setText(""+price+" tk");
			 payLable.setVisible(true);
			 money.setVisible(true);
			 vehicleList.setAll(Main.reservationSystem.getVehicles());

		} catch (NotAvailableException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void sendMoney(ActionEvent event) {
		JOptionPane.showMessageDialog(null, "Payment Complete");
		payLable.setVisible(false);
		money.setVisible(false);
	}
	public void cancleVehicle(ActionEvent event) {
		Vehicle vehicle=vehicleTable.getSelectionModel().getSelectedItem();
		try {
			Main.reservationSystem.cancelReservation(vehicle);
			vehicleList.setAll(Main.reservationSystem.getVehicles());
		} catch (NotAvailableException e) {
			e.printStackTrace();
		}
	}
	
	
}
