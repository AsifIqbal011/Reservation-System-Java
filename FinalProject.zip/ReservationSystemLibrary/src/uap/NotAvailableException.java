package uap;

public class NotAvailableException extends Exception {

	public NotAvailableException(String msg) {
		super(msg);
	}

}
